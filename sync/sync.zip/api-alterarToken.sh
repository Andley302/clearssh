#!/bin/bash
clear
tokenAntigo=$1
tokenNovo=$2
password=$3
[[ ! -e /bin/versao ]] && rm -rf /bin/menu
if [[ -e "/etc/SSHPlus/senha/$tokenAntigo" ]]; then
    senha=$(cat /etc/SSHPlus/senha/$tokenAntigo)
else
    senha="Null"
fi
datauser=$(chage -l $tokenAntigo |grep -i co |awk -F : '{print $2}')
if [ $datauser = never ] 2> /dev/null
then
data="\033[1;33mNunca\033[0m"
else
    databr="$(date -d "$datauser" +"%Y%m%d")"
    hoje="$(date -d today +"%Y%m%d")"
    if [ $hoje -ge $databr ]
    then
    data="\033[1;31mVenceu\033[0m"
    else
    dat="$(date -d"$datauser" '+%Y-%m-%d')"
    data=$(echo -e "$((($(date -ud $dat +%s)-$(date -ud $(date +%Y-%m-%d) +%s))/86400))")
    fi
fi
diasRestantes=$(printf '%-1s' "$data")
#deleta usuario
userdel $tokenAntigo
echo "Deletando token antigo"
grep -v ^$tokenAntigo[[:space:]] /root/usuarios.db > /tmp/ph ; cat /tmp/ph > /root/usuarios.db
rm /etc/SSHPlus/senha/tokenAntigo 1>/dev/null 2>/dev/null
rm /etc/usuarios/$tokenAntigo 1>/dev/null 2>/dev/null
echo "Adicionando usuário com os dias restantes"
./api-addUser.sh $tokenNovo $password $diasRestantes  
echo "Token Alterado!"

