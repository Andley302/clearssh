#!/bin/bash
username=$1
password=$2
dias=$3
sshlimiter='1'
awk -F : ' { print $1 }' /etc/passwd > /tmp/users 
if [[ `grep -c /$username: /etc/passwd` -ne 0 ]]
then
datauser=$(chage -l $username |grep -i co |awk -F : '{print $2}')
dat="$(date -d"$datauser" '+%Y-%m-%d')"
data=$(echo -e "$((($(date -ud $dat +%s)-$(date -ud $(date +%Y-%m-%d) +%s))/86400))")
Data=$(printf "$data")

#if [ $Data -le 1 ]; then
#soma='31'
#finaldate=$(date "+%Y-%m-%d" -d "+$soma days")
#chage -E $finaldate $username
#echo "Usuário de 1 dia restante | Adicionado +31 dias";
#else
#soma=$(($Data+30))
#finaldate=$(date "+%Y-%m-%d" -d "+$soma days")
#chage -E $finaldate $username
#echo "Usuario +de 1 dia sobrando | Adicionado +30 dias";
#fi

if [ $Data -gt 6 ] ;then
  echo "Renovação ignorada, data maior ou igual a 6 dias";
  echo "Faltam" $Data "dias";
  
elif [$Data -le 1 ]; then
   soma='31'
   finaldate=$(date "+%Y-%m-%d" -d "+$soma days")
   chage -E $finaldate $username
   echo "Usuário de 1 dia restante | Adicionado +31 dias";
else
  soma=$(($Data+30))
  finaldate=$(date "+%Y-%m-%d" -d "+$soma days");
  chage -E $finaldate $username;
  echo "Usuário de + de 1 dia restante | Adicionado +30 dias";
fi

exit 1	
else
final=$(date "+%Y-%m-%d" -d "+$dias days")
gui=$(date "+%d/%m/%Y" -d "+$dias days")
pass=$(perl -e 'print crypt($ARGV[0], "password")' $password)
useradd -e $final -M -s /bin/false -p $pass $username
[ $? -eq 0 ];
echo "$password" > /etc/SSHPlus/senha/$username
echo "$username $sshlimiter" >> /root/usuarios.db
#clear
echo "Script finalizado com sucesso!"
fi
exit
