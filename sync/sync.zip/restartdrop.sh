#!/bin/bash
echo "Reiniciando dropbear...";
/etc/init.d/dropbear restart;

