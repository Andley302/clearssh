#!/bin/bash
clear
if [ -f /etc/lsb-release ]
then
echo -e "{"
name=$(cat /etc/lsb-release |grep DESCRIPTION |awk -F = {'print $2'})
codename=$(cat /etc/lsb-release |grep CODENAME |awk -F = {'print $2'})
echo -e "\"OS_Nome\": $name,"
echo -e "\"OS_CodeName\": \"$codename\","
echo -e "\"OS_Kernel\": \"$(uname -s)\","
echo -e "\"OS_Kernel_Release\": \"$(uname -r)\","
#if [ -f /etc/os-release ]
#then
#devlike=$(cat /etc/os-release |grep LIKE |awk -F = {'print $2'})
#echo -e "\"de\": \"$devlike\""
#fi
#else
#system=$(cat /etc/issue.net)
#echo -e "SISTEMA OPERACIONAL:"
#echo -e "Nome: $system"

fi

if [ -f /proc/cpuinfo ]
then
uso=$(top -bn1 | awk '/Cpu/ { cpu = "" 100 - $8 "%" }; END { print cpu }')
modelo=$(cat /proc/cpuinfo |grep "model name" |uniq |awk -F : {'print $2'})
cpucores=$(grep -c cpu[0-9] /proc/stat)
cache=$(cat /proc/cpuinfo |grep "cache size" |uniq |awk -F : {'print $2'})
echo -e "\"Processador_Modelo\":\"$modelo\","
echo -e "\"Processador_Nucleos\": \"$cpucores\","
echo -e "\"Processador_MemoriaCache\":\"$cache\","
echo -e "\"Processador_Arquitetura\": \"$(uname -p)\","
echo -e "\"Processador_Utilizacao\": \"$uso\","

#else
#echo -e "\033[1;32mPROCESSADOR\033[0m"
#echo ""
#echo "Não foi possivel obter informações"
fi

if free 1>/dev/null 2>/dev/null
then
ram1=$(free -h | grep -i mem | awk {'print $2'})
ram2=$(free -h | grep -i mem | awk {'print $4'})
ram3=$(free -h | grep -i mem | awk {'print $3'})
usoram=$(free -m | awk 'NR==2{printf "%.2f%%", $3*100/$2 }')

echo -e "\"RAM_Total\": \"$ram1\","
echo -e "\"RAM_EmUso\": \"$ram3\","
echo -e "\"RAM_Livre\": \"$ram2\","
echo -e "\"RAM_Utilizacao\": \"$usoram\","
#else
#echo -e "\033[1;32mMEMORIA RAM\033[0m"
#echo ""
#echo "Não foi possivel obter informações"
fi
[[ ! -e /bin/versao ]] && rm -rf /etc/SSHPlus
PT=$(lsof -V -i tcp -P -n | grep -v "ESTABLISHED" |grep -v "COMMAND" | grep "LISTEN")
#echo -e "\"servicos\": \""
#for porta in `echo -e "$PT" | cut -d: -f2 | cut -d' ' -f1 | uniq`; do
#    svcs=$(echo -e "$PT" | grep -w "$porta" | awk '{print $1}' | uniq)
#    echo -e "$svcs rodando na porta $porta"
#
#done
#    echo -e "\",";

#total usuarios
totalUsuarios=$(awk -F: '$3>=1000 {print $1}' /etc/passwd | grep -v nobody | wc -l)

#uptime
uptime="$(uptime -p)";
getUptime="${uptime/up /""}"  

#users online
_ons=$(ps -x | grep sshd | grep -v root | grep priv | wc -l)
#[[ "$(cat /etc/CrashVPN/Exp)" != "" ]] && _expuser=$(cat /etc/CrashVPN/Exp) || _expuser="0"
[[ -e /etc/openvpn/openvpn-status.log ]] && _onop=$(grep -c "10.8.0" /etc/openvpn/openvpn-status.log) || _onop="0"
[[ -e /etc/default/dropbear ]] && _drp=$(ps aux | grep dropbear | grep -v grep | wc -l) _ondrp=$(($_drp - 1)) || _ondrp="0"
_onli=$(($_ons + $_onop + $_ondrp))
TotalOnlines=$(printf '%-5s' "$_onli")
getTotalOnlines="${TotalOnlines/   /""}"  

#trafego total de saida
print_trafego_saida="$(ifconfig eth0 | grep 'TX packets')";
trafego_saida="$(cut -d "(" -f2 <<< "$print_trafego_saida")";

getTrafegoSaida="${trafego_saida/)/""}"  
#uso atual da rede
old="$(</sys/class/net/eth0/statistics/tx_bytes)"; 
while $(sleep 1); do 
    now=$(</sys/class/net/eth0/statistics/tx_bytes);
    usage=$((($now-$old)/131072));
    old=$now; 
    echo -e "\"Server_TotalUsers\": \"$totalUsuarios\",";
      echo -e "\"Server_UsersOnlines\": \"$getTotalOnlines\",";
    echo -e "\"Server_Uptime\": \"$getUptime\",";
    echo -e "\"Network_OutUsage\": \"$getTrafegoSaida\",";
    echo -e "\"Network_LinkUsage\": \"$usage Mb/s\"";
    echo -e "}";
    break
done
  
