#!/bin/bash
sync; 
echo 3 > /proc/sys/vm/drop_caches 
echo 3 > /proc/sys/vm/drop_caches && swapoff -a && swapon -a;
cat /dev/null > /var/log/auth.log
cat /dev/null > /var/log/btmp
cd /var/log && rm -rf auth*
echo "Cleared!";