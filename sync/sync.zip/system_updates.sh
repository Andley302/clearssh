#!/bin/bash
apt-get autoremove -y;
apt-get autoclean -y;
apt-get -f install -y;
apt-get autoclean -y;
apt-get update -y;
apt-get upgrade -y;
apt-get -f install -y;
apt-get autoremove -y;
apt-get autoclean -y;
