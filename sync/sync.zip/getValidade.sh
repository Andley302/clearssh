#!/bin/bash
clear
usuario=$1
[[ ! -e /bin/versao ]] && rm -rf /bin/menu
if [[ -e "/etc/SSHPlus/senha/$usuario" ]]; then
    senha=$(cat /etc/SSHPlus/senha/$usuario)
else
    senha="Null"
fi
datauser=$(chage -l $usuario |grep -i co |awk -F : '{print $2}')
data="$(date -d"$datauser" '+%Y-%m-%d')"
echo -e "$data"

