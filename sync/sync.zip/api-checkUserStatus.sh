#!/bin/bash
token=$1;
totalUsuarios=$(awk -F: '$3>=1000 {print $1}' /etc/passwd | grep -v nobody | wc -l)
usuario_existe=$(grep $token /etc/passwd)
if [ -z "$usuario_existe" ]
then
   echo $totalUsuarios;
else
    echo "Renew user";
fi

